package com.ug5a.soal1;
import java.util.Scanner;
import javax.naming.NameAlreadyBoundException;

public class Keyboard {
    String merkModel;
    long harga;

    public static void setMerkModel(String merkModel){

    }

    public static void setHarga(long Harga){

    }

    String getMerkModel(){return merkModel;}

    long getHarga(){setHarga();}
}
