package com.ug5a.soal1;
import java.util.Scanner;

public class TransPay {
    String nama;
    long saldo;

    String getNama(){return nama;}

    long getSaldo(){return saldo;}

    public static void setNama(String nama){
        System.out.println (nama);}

    public static void setSaldo(long saldo){
        System.out.println(saldo);}

    void topUp(long topUp){

    }

    void bayar(int){
        int getSaldo();}
}
