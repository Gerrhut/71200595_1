package com.ug5a.soal2;

public class Sepatu {
    private String kode;
    private Integer nextnum;
    private String merkModel;
    private Integer ukuran;
    private long harga;
    private Integer stok;

    public Sepatu(String argMerkModel, Integer argUkuran, long argHarga, Integer argStok){}

    public String getKode() {
        return this.kode;
    }

    public String getMerkModel() {
        return this.merkModel;
    }

    public Integer getUkuran() {
        return ukuran;
    }

    public long getHarga() {
        return harga;
    }

    public Integer getStok() {
        return stok;
    }
}

